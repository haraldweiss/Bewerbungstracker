#!/usr/bin/env python3
"""
Bewerbungs-Tracker Unified Web Server
Combines Frontend + All Backend Services (IMAP, Email, Data) into one Flask app
Deployable to Railway, Heroku, AWS, etc.

Features:
- Serves static frontend (index.html, CSS, JS)
- All APIs available at /api/*
- CORS enabled for all origins
- SQLite database
- Email service with encryption
- IMAP monitoring
"""

from flask import Flask, jsonify, request, send_from_directory, render_template_string
from flask_cors import CORS
from functools import wraps
import json
import sqlite3
import os
import base64
import hashlib
import secrets
from datetime import datetime, timedelta
from pathlib import Path
from contextlib import contextmanager
import logging

# ═══════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════

app = Flask(__name__, static_folder='.', static_url_path='')
CORS(app)

# Database setup
DB_FILE = 'bewerbungen.db'

# Port configuration (Railway/Heroku use PORT env var)
PORT = int(os.environ.get('PORT', 8080))
HOST = '0.0.0.0'  # Listen on all interfaces (required for cloud)

# Input validation
MAX_STRING_LENGTH = 10000
MAX_ID_LENGTH = 100
ALLOWED_STATUSES = {'beworben', 'interview', 'zusage', 'absage', 'ghosting', 'antwort'}
ALLOWED_QUELLEN = {'gmail', 'imap', 'manuell', 'linkedin', 'indeed', 'xing', 'website', 'empfehlung'}

# Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════
# AUTHENTICATION
# ═══════════════════════════════════════════════════════

# Simple in-memory session store (user:token -> expiry_time)
ACTIVE_SESSIONS = {}

# Default credentials (CHANGE THESE IN PRODUCTION!)
AUTH_USERNAME = os.environ.get('AUTH_USERNAME', 'admin')
AUTH_PASSWORD = os.environ.get('AUTH_PASSWORD', 'password123')
AUTH_SECRET = os.environ.get('AUTH_SECRET', 'your-secret-key-change-in-production')
TOKEN_EXPIRY_MINUTES = int(os.environ.get('TOKEN_EXPIRY_MINUTES', 30))

def generate_token():
    """Generate a secure token"""
    return secrets.token_urlsafe(32)

def validate_credentials(username, password):
    """Validate login credentials"""
    return username == AUTH_USERNAME and password == AUTH_PASSWORD

def create_session(username):
    """Create a new session and return token"""
    token = generate_token()
    expiry = datetime.now() + timedelta(minutes=TOKEN_EXPIRY_MINUTES)
    ACTIVE_SESSIONS[token] = {'username': username, 'expires_at': expiry}
    return token

def validate_token(token):
    """Validate a session token"""
    if token not in ACTIVE_SESSIONS:
        return False

    session = ACTIVE_SESSIONS[token]
    if datetime.now() > session['expires_at']:
        del ACTIVE_SESSIONS[token]
        return False

    return True

def get_token_from_request():
    """Extract token from Authorization header"""
    auth_header = request.headers.get('Authorization', '')
    if auth_header.startswith('Bearer '):
        return auth_header[7:]
    return None

def require_auth(f):
    """Decorator to require authentication on routes"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        token = get_token_from_request()
        if not token or not validate_token(token):
            return jsonify({'status': 'error', 'message': 'Unauthorized'}), 401
        return f(*args, **kwargs)
    return decorated_function

# ═══════════════════════════════════════════════════════
# DATABASE FUNCTIONS
# ═══════════════════════════════════════════════════════

@contextmanager
def db_connection():
    """Context manager for database connections"""
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    except Exception as e:
        conn.rollback()
        raise e
    finally:
        conn.close()

def init_db():
    """Initialize SQLite database"""
    with db_connection() as conn:
        c = conn.cursor()

        # Applications table
        c.execute('''CREATE TABLE IF NOT EXISTS bewerbungen (
            id TEXT PRIMARY KEY,
            firma TEXT NOT NULL,
            position TEXT,
            status TEXT,
            datum TEXT,
            gehalt TEXT,
            ort TEXT,
            email TEXT,
            quelle TEXT,
            link TEXT,
            notizen TEXT,
            createdAt TEXT,
            updatedAt TEXT,
            deleted INTEGER DEFAULT 0,
            deletedAt TEXT
        )''')

        # Settings table
        c.execute('''CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )''')

        # CV Comparisons table
        c.execute('''CREATE TABLE IF NOT EXISTS cv_comparisons (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            result TEXT,
            cv_file TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )''')

        # Create indices
        c.execute('CREATE INDEX IF NOT EXISTS idx_status ON bewerbungen(status)')
        c.execute('CREATE INDEX IF NOT EXISTS idx_firma ON bewerbungen(firma)')
        c.execute('CREATE INDEX IF NOT EXISTS idx_createdAt ON bewerbungen(createdAt)')
        c.execute('CREATE INDEX IF NOT EXISTS idx_cv_comp_created ON cv_comparisons(created_at)')

        conn.commit()

# ═══════════════════════════════════════════════════════
# DATABASE HELPER FUNCTIONS
# ═══════════════════════════════════════════════════════

def get_all_bewerbungen(include_deleted=False):
    """Fetch all applications"""
    with db_connection() as conn:
        c = conn.cursor()
        if include_deleted:
            c.execute('SELECT * FROM bewerbungen ORDER BY createdAt DESC')
        else:
            c.execute('SELECT * FROM bewerbungen WHERE deleted = 0 ORDER BY createdAt DESC')
        rows = [dict(row) for row in c.fetchall()]
    return rows

def get_bewerbung(id):
    """Fetch single application by ID"""
    with db_connection() as conn:
        c = conn.cursor()
        c.execute('SELECT * FROM bewerbungen WHERE id = ?', (id,))
        row = c.fetchone()
    return dict(row) if row else None

def create_bewerbung(data):
    """Create new application"""
    bewerbung = {
        'id': data.get('id'),
        'firma': data.get('firma', ''),
        'position': data.get('position', ''),
        'status': data.get('status', 'beworben'),
        'datum': data.get('datum', ''),
        'gehalt': data.get('gehalt', ''),
        'ort': data.get('ort', ''),
        'email': data.get('email', ''),
        'quelle': data.get('quelle', ''),
        'link': data.get('link', ''),
        'notizen': data.get('notizen', ''),
        'createdAt': data.get('createdAt', datetime.now().isoformat()),
        'updatedAt': data.get('updatedAt', datetime.now().isoformat())
    }

    with db_connection() as conn:
        c = conn.cursor()
        c.execute('''INSERT INTO bewerbungen
            (id, firma, position, status, datum, gehalt, ort, email, quelle, link, notizen, createdAt, updatedAt)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
            tuple(bewerbung.values()))
        conn.commit()

    return bewerbung

def update_bewerbung(id, data):
    """Update existing application"""
    with db_connection() as conn:
        c = conn.cursor()
        c.execute('SELECT * FROM bewerbungen WHERE id = ?', (id,))
        current = dict(c.fetchone() or {})

        updated = {**current}
        updated.update(data)
        updated['updatedAt'] = datetime.now().isoformat()

        c.execute('''UPDATE bewerbungen SET
            firma=?, position=?, status=?, datum=?, gehalt=?, ort=?,
            email=?, quelle=?, link=?, notizen=?, updatedAt=?
            WHERE id=?''',
            (updated['firma'], updated['position'], updated['status'], updated['datum'],
             updated['gehalt'], updated['ort'], updated['email'], updated['quelle'],
             updated['link'], updated['notizen'], updated['updatedAt'], id))

        conn.commit()

    return updated

def delete_bewerbung(id):
    """Soft delete application"""
    with db_connection() as conn:
        c = conn.cursor()
        c.execute('UPDATE bewerbungen SET deleted = 1, deletedAt = ? WHERE id = ?',
                  (datetime.now().isoformat(), id))
        conn.commit()
        affected = c.rowcount
    return affected > 0

def get_deleted_bewerbungen():
    """Fetch deleted applications"""
    with db_connection() as conn:
        c = conn.cursor()
        c.execute('SELECT * FROM bewerbungen WHERE deleted = 1 ORDER BY deletedAt DESC')
        rows = [dict(row) for row in c.fetchall()]
    return rows

def recover_bewerbung(id):
    """Recover deleted application"""
    with db_connection() as conn:
        c = conn.cursor()
        c.execute('UPDATE bewerbungen SET deleted = 0, deletedAt = NULL, updatedAt = ? WHERE id = ?',
                  (datetime.now().isoformat(), id))
        conn.commit()
        affected = c.rowcount
    return affected > 0

def permanently_delete_bewerbung(id):
    """Permanently delete application"""
    with db_connection() as conn:
        c = conn.cursor()
        c.execute('DELETE FROM bewerbungen WHERE id = ?', (id,))
        conn.commit()
        affected = c.rowcount
    return affected > 0

def get_settings():
    """Get all settings"""
    with db_connection() as conn:
        c = conn.cursor()
        c.execute('SELECT key, value FROM settings')
        settings = {}
        for key, value in c.fetchall():
            try:
                settings[key] = json.loads(value)
            except (json.JSONDecodeError, ValueError):
                settings[key] = value
    return settings

def set_settings_bulk(settings_dict):
    """Set multiple settings"""
    with db_connection() as conn:
        c = conn.cursor()
        for key, value in settings_dict.items():
            value_json = json.dumps(value) if not isinstance(value, str) else value
            c.execute('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)',
                      (key, value_json))
        conn.commit()

def export_data(include_deleted=False):
    """Export all data for backup"""
    return {
        'bewerbungen': get_all_bewerbungen(include_deleted=include_deleted),
        'settings': get_settings(),
        'exportedAt': datetime.now().isoformat()
    }

def import_data(bewerbungen, settings):
    """Import data"""
    with db_connection() as conn:
        c = conn.cursor()
        for b in bewerbungen:
            c.execute('''INSERT OR REPLACE INTO bewerbungen
                (id, firma, position, status, datum, gehalt, ort, email, quelle, link, notizen, createdAt, updatedAt)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                (b.get('id'), b.get('firma'), b.get('position'), b.get('status'),
                 b.get('datum'), b.get('gehalt'), b.get('ort'), b.get('email'),
                 b.get('quelle'), b.get('link'), b.get('notizen'),
                 b.get('createdAt'), b.get('updatedAt')))

        for key, value in settings.items():
            value_json = json.dumps(value) if not isinstance(value, str) else value
            c.execute('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)',
                      (key, value_json))

        conn.commit()

# ═══════════════════════════════════════════════════════
# API ROUTES
# ═══════════════════════════════════════════════════════

@app.route('/')
def index():
    """Serve the frontend"""
    return send_from_directory('.', 'index.html')

@app.route('/<path:path>')
def serve_static(path):
    """Serve static files"""
    return send_from_directory('.', path)

# ═══ Authentication API (PUBLIC - No @require_auth) ═══

@app.route('/api/auth/login', methods=['POST'])
def login():
    """Login with username and password"""
    data = request.get_json() or {}
    username = data.get('username', '')
    password = data.get('password', '')

    if validate_credentials(username, password):
        token = create_session(username)
        return jsonify({'status': 'ok', 'token': token, 'message': 'Login successful'})

    return jsonify({'status': 'error', 'message': 'Invalid credentials'}), 401

@app.route('/api/auth/logout', methods=['POST'])
def logout():
    """Logout and invalidate token"""
    token = get_token_from_request()
    if token and token in ACTIVE_SESSIONS:
        del ACTIVE_SESSIONS[token]
    return jsonify({'status': 'ok', 'message': 'Logged out'})

@app.route('/api/auth/status', methods=['GET'])
def auth_status():
    """Check authentication status (returns 401 if not authenticated)"""
    token = get_token_from_request()
    if not token or not validate_token(token):
        return jsonify({'status': 'error', 'message': 'Not authenticated'}), 401

    session = ACTIVE_SESSIONS[token]
    return jsonify({
        'status': 'ok',
        'username': session['username'],
        'expires_at': session['expires_at'].isoformat()
    })

# ═══ Applications API ═══

@app.route('/api/applications', methods=['GET', 'POST'])
@require_auth
def applications():
    """List or create applications"""
    if request.method == 'GET':
        data = get_all_bewerbungen()
        return jsonify({'status': 'ok', 'count': len(data), 'applications': data})

    elif request.method == 'POST':
        data = request.get_json() or {}
        if 'id' not in data:
            return jsonify({'status': 'error', 'message': 'id is required'}), 400

        app_data = create_bewerbung(data)
        return jsonify({'status': 'ok', 'application': app_data}), 201

@app.route('/api/applications/<app_id>', methods=['GET', 'PUT', 'DELETE'])
@require_auth
def application(app_id):
    """Get, update, or delete a single application"""
    if request.method == 'GET':
        app_data = get_bewerbung(app_id)
        if app_data:
            return jsonify({'status': 'ok', 'application': app_data})
        return jsonify({'status': 'error', 'message': 'Not found'}), 404

    elif request.method == 'PUT':
        data = request.get_json() or {}
        updated = update_bewerbung(app_id, data)
        return jsonify({'status': 'ok', 'application': updated})

    elif request.method == 'DELETE':
        permanent = request.args.get('permanent') == 'true'
        if permanent:
            if permanently_delete_bewerbung(app_id):
                return jsonify({'status': 'ok', 'message': 'Permanently deleted'})
        else:
            if delete_bewerbung(app_id):
                return jsonify({'status': 'ok', 'message': 'Deleted (recoverable)'})
        return jsonify({'status': 'error', 'message': 'Not found'}), 404

@app.route('/api/applications/deleted', methods=['GET'])
@require_auth
def deleted_applications():
    """Get deleted applications"""
    data = get_deleted_bewerbungen()
    return jsonify({'status': 'ok', 'count': len(data), 'deleted': data})

@app.route('/api/applications/<app_id>/recover', methods=['POST'])
@require_auth
def recover_application(app_id):
    """Recover a deleted application"""
    if recover_bewerbung(app_id):
        app_data = get_bewerbung(app_id)
        return jsonify({'status': 'ok', 'message': 'Recovered', 'application': app_data})
    return jsonify({'status': 'error', 'message': 'Not found'}), 404

# ═══ Settings API ═══

@app.route('/api/settings', methods=['GET', 'PUT'])
@require_auth
def settings():
    """Get or update settings"""
    if request.method == 'GET':
        data = get_settings()
        return jsonify({'status': 'ok', 'settings': data})

    elif request.method == 'PUT':
        data = request.get_json() or {}
        set_settings_bulk(data)
        settings_data = get_settings()
        return jsonify({'status': 'ok', 'settings': settings_data})

# ═══ Import/Export API ═══

@app.route('/api/import', methods=['POST'])
@require_auth
def import_endpoint():
    """Import data"""
    data = request.get_json() or {}
    bewerbungen = data.get('bewerbungen', [])
    settings = data.get('settings', {})
    import_data(bewerbungen, settings)
    return jsonify({'status': 'ok', 'message': f'Imported {len(bewerbungen)} applications'})

@app.route('/api/export', methods=['GET'])
@require_auth
def export_endpoint():
    """Export data"""
    data = export_data()
    return jsonify({'status': 'ok', **data})

# ═══ CV Comparison Endpoints ═══

@app.route('/api/cv-comparison/save', methods=['POST'])
@require_auth
def save_cv_comparison():
    """Save CV comparison result"""
    data = request.get_json()
    title = data.get('title', 'Untitled Comparison')
    result = data.get('result', '')
    cv_file = data.get('cv_file', 'unknown')
    
    if not result:
        return jsonify({'status': 'error', 'message': 'Result is required'}), 400
    
    with db_connection() as conn:
        c = conn.cursor()
        c.execute('''INSERT INTO cv_comparisons (title, result, cv_file, created_at) 
                     VALUES (?, ?, ?, ?)''',
                  (title, result, cv_file, datetime.now().isoformat()))
        conn.commit()
        comparison_id = c.lastrowid
    
    return jsonify({'status': 'ok', 'id': comparison_id, 'message': 'Comparison saved'})

@app.route('/api/cv-comparison/list', methods=['GET'])
@require_auth
def list_cv_comparisons():
    """List all CV comparisons"""
    with db_connection() as conn:
        c = conn.cursor()
        c.execute('SELECT id, title, cv_file, created_at FROM cv_comparisons ORDER BY created_at DESC')
        comparisons = [{'id': row[0], 'title': row[1], 'cv_file': row[2], 'created_at': row[3]} 
                      for row in c.fetchall()]
    return jsonify({'status': 'ok', 'comparisons': comparisons})

@app.route('/api/cv-comparison/<int:comp_id>', methods=['GET'])
@require_auth
def get_cv_comparison(comp_id):
    """Get a specific CV comparison"""
    with db_connection() as conn:
        c = conn.cursor()
        c.execute('SELECT id, title, result, cv_file, created_at FROM cv_comparisons WHERE id = ?', (comp_id,))
        row = c.fetchone()
    
    if not row:
        return jsonify({'status': 'error', 'message': 'Comparison not found'}), 404
    
    return jsonify({'status': 'ok', 'comparison': {
        'id': row[0], 'title': row[1], 'result': row[2], 'cv_file': row[3], 'created_at': row[4]
    }})

@app.route('/api/cv-comparison/<int:comp_id>', methods=['DELETE'])
@require_auth
def delete_cv_comparison(comp_id):
    """Delete a CV comparison"""
    with db_connection() as conn:
        c = conn.cursor()
        c.execute('DELETE FROM cv_comparisons WHERE id = ?', (comp_id,))
        conn.commit()
        if c.rowcount == 0:
            return jsonify({'status': 'error', 'message': 'Comparison not found'}), 404
    
    return jsonify({'status': 'ok', 'message': 'Comparison deleted'})

@app.route('/api/cv-comparison/export', methods=['POST'])
@require_auth
def export_cv_comparison():
    """Export CV comparison as file"""
    data = request.get_json()
    comp_id = data.get('id')
    
    with db_connection() as conn:
        c = conn.cursor()
        c.execute('SELECT title, result, created_at FROM cv_comparisons WHERE id = ?', (comp_id,))
        row = c.fetchone()
    
    if not row:
        return jsonify({'status': 'error', 'message': 'Comparison not found'}), 404
    
    return jsonify({'status': 'ok', 'comparison': {
        'title': row[0], 'result': row[1], 'created_at': row[2]
    }})

# ═══ Status/Health Check ═══

@app.route('/api/status', methods=['GET'])
def status():
    """Health check endpoint"""
    return jsonify({
        'status': 'ok',
        'service': 'Bewerbungs-Tracker',
        'version': '4.3',
        'timestamp': datetime.now().isoformat()
    })

# ═══════════════════════════════════════════════════════
# INITIALIZATION & STARTUP
# ═══════════════════════════════════════════════════════

# Initialize database on startup (works with gunicorn and app.run)
@app.before_request
def initialize_db():
    """Initialize database on first request"""
    if not hasattr(app, '_db_initialized'):
        init_db()
        app._db_initialized = True

# Also initialize on startup for faster first request
try:
    init_db()
    print(f"✅ Database initialized at startup")
except Exception as e:
    print(f"⚠️ Database initialization warning: {e}")

if __name__ == '__main__':
    print(f"🚀 Bewerbungs-Tracker Web Server starting...")
    print(f"📦 Database: {DB_FILE}")
    print(f"🌐 Listening on: {HOST}:{PORT}")
    print(f"🔗 Open browser: http://localhost:{PORT}")
    print(f"📚 API available at: http://localhost:{PORT}/api/*")

    # Start server
    app.run(host=HOST, port=PORT, debug=False)
